"""
database.py  –  FinSight Pro data layer
Powered by real CSV datasets: users_data.csv + cards_data.csv
"""

import os
import random
from datetime import date, datetime, timedelta
from typing import Dict, Any, List, Optional

import pandas as pd

# ─────────────────────────────────────────────
# Load CSVs once at startup
# ─────────────────────────────────────────────
_BASE = os.path.dirname(__file__)

_users_df = pd.read_csv(os.path.join(_BASE, "users_data.csv"))
_cards_df = pd.read_csv(os.path.join(_BASE, "cards_data.csv"))


# ─────────────────────────────────────────────
# Money helpers
# ─────────────────────────────────────────────
def _money(s) -> float:
    """'$12,400' -> 12400.0"""
    return float(str(s).replace("$", "").replace(",", "").strip() or 0)


def _fmt(v: float) -> str:
    return f"${v:,.0f}"


def _today() -> date:
    return date.today()


def _now() -> datetime:
    return datetime.utcnow()


# Pre-parse numeric columns once
_users_df["yearly_income_num"]      = _users_df["yearly_income"].apply(_money)
_users_df["total_debt_num"]         = _users_df["total_debt"].apply(_money)
_users_df["per_capita_income_num"]  = _users_df["per_capita_income"].apply(_money)
_cards_df["credit_limit_num"]       = _cards_df["credit_limit"].apply(_money)

# ─────────────────────────────────────────────
# Auth helpers
# ─────────────────────────────────────────────
TOKENS: Dict[str, int] = {}   # token -> user_id (int)

def _get_user_row(user_id: int):
    rows = _users_df[_users_df["id"] == user_id]
    if rows.empty:
        return None
    return rows.iloc[0]

def _get_user_cards(user_id: int) -> pd.DataFrame:
    return _cards_df[_cards_df["client_id"] == user_id].copy()

def list_all_user_ids() -> List[int]:
    return _users_df["id"].tolist()

# ─────────────────────────────────────────────
# USERS  (for auth)
# ─────────────────────────────────────────────
def get_user_by_id(user_id: int) -> Optional[Dict]:
    row = _get_user_row(user_id)
    if row is None:
        return None
    return {
        "id":    int(row["id"]),
        "name":  f"User {row['id']}",
        "email": f"user{row['id']}@finsightpro.io",
        "gender": row["gender"],
        "age":   int(row["current_age"]),
    }

def get_user_by_email(email: str) -> Optional[Dict]:
    """Extract user_id from email pattern user{id}@..."""
    try:
        uid = int(email.split("@")[0].replace("user", ""))
        return get_user_by_id(uid)
    except Exception:
        return None

# ─────────────────────────────────────────────
# DASHBOARD  (code1.html)
# ─────────────────────────────────────────────
def get_dashboard(user_id: int) -> Dict:
    row   = _get_user_row(user_id)
    cards = _get_user_cards(user_id)

    if row is None:
        return {}

    income       = row["yearly_income_num"]
    total_debt   = row["total_debt_num"]
    credit_score = int(row["credit_score"])
    monthly_income = income / 12

    total_limit   = cards["credit_limit_num"].sum()
    total_balance = total_limit * 0.28
    monthly_cf    = monthly_income * 0.22

    est_min_payments = total_debt * 0.025
    dti = round(est_min_payments / monthly_income, 4) if monthly_income else 0
    net_worth = income * 3.2 - total_debt

    cs_trend = "up" if credit_score >= 700 else "down"
    cs_change = round((credit_score - 650) / 65, 1)

    return {
        "user_id": user_id,
        "name": f"User {user_id}",
        "age": int(row["current_age"]),
        "gender": row["gender"],
        "net_worth": round(net_worth, 2),
        "credit_score": credit_score,
        "monthly_cash_flow": round(monthly_cf, 2),
        "debt_to_income_ratio": dti,
        "total_cards": len(cards),
        "kpi_cards": [
            {"label": "Net Worth",           "value": _fmt(net_worth),    "change":  4.2,  "trend": "up"},
            {"label": "Credit Score",         "value": str(credit_score),  "change":  cs_change, "trend": cs_trend},
            {"label": "Monthly Cash Flow",    "value": _fmt(monthly_cf),   "change": -3.1,  "trend": "down"},
            {"label": "Debt-to-Income Ratio", "value": f"{dti*100:.1f}%",  "change": -0.8,  "trend": "up"},
        ],
        "last_updated": _now().isoformat(),
    }


# ─────────────────────────────────────────────
# FINANCIAL HEALTH  (code.html)
# ─────────────────────────────────────────────
def _score_band(score: int):
    if score >= 80: return "excellent"
    if score >= 65: return "good"
    if score >= 45: return "fair"
    return "poor"

def get_financial_health(user_id: int) -> Dict:
    row   = _get_user_row(user_id)
    cards = _get_user_cards(user_id)

    if row is None:
        return {}

    income     = row["yearly_income_num"]
    total_debt = row["total_debt_num"]
    credit_score = int(row["credit_score"])
    monthly_income = income / 12

    savings_rate_pct = max(0, min(40, (income - total_debt * 0.12) / income * 100))
    savings_score    = int(min(100, savings_rate_pct * 2.5))

    dti_ratio  = total_debt / income if income else 1
    debt_score = int(max(0, min(100, 100 - dti_ratio * 60)))

    pci       = row["per_capita_income_num"]
    ef_months = max(0, min(12, pci / (monthly_income * 0.5 + 1)))
    ef_score  = int(min(100, ef_months / 6 * 100))

    num_cards = int(row["num_credit_cards"])
    inv_score = min(100, 50 + num_cards * 8)

    total_limit  = cards["credit_limit_num"].sum()
    est_balance  = total_limit * 0.28
    utilisation  = est_balance / total_limit if total_limit else 0.5
    util_score   = int(max(0, min(100, (1 - utilisation) * 100)))

    cs_score = int((credit_score - 300) / 550 * 100)

    overall = int((savings_score + debt_score + ef_score + inv_score + util_score + cs_score) / 6)

    categories = [
        {
            "name": "Savings Rate",
            "score": savings_score,
            "status": _score_band(savings_score),
            "recommendation": f"Saving ~{savings_rate_pct:.0f}% of income. " +
                ("Excellent pace — consider index funds." if savings_score >= 80 else "Aim for 20%+ to build wealth faster."),
        },
        {
            "name": "Debt Management",
            "score": debt_score,
            "status": _score_band(debt_score),
            "recommendation": f"Total debt {_fmt(total_debt)} against income {_fmt(income)}. " +
                ("Well managed." if debt_score >= 70 else "Focus on high-interest debt first (avalanche method)."),
        },
        {
            "name": "Emergency Fund",
            "score": ef_score,
            "status": _score_band(ef_score),
            "recommendation": f"~{ef_months:.1f} months covered. " +
                ("Strong buffer." if ef_score >= 80 else "Target 6 months of expenses."),
        },
        {
            "name": "Investment Diversification",
            "score": inv_score,
            "status": _score_band(inv_score),
            "recommendation": f"{num_cards} active cards/accounts. " +
                ("Consider broadening into ETFs or bonds." if inv_score < 80 else "Good financial product diversity."),
        },
        {
            "name": "Credit Utilisation",
            "score": util_score,
            "status": _score_band(util_score),
            "recommendation": f"Est. utilisation {utilisation*100:.0f}% across {len(cards)} cards. " +
                ("Optimal range is under 10%." if util_score < 80 else "Excellent — keep below 10%."),
        },
        {
            "name": "Credit Score",
            "score": cs_score,
            "status": _score_band(cs_score),
            "recommendation": f"Score {credit_score}. " +
                ("Excellent — eligible for best rates." if credit_score >= 750
                 else "Pay on time, reduce balances to improve."),
        },
    ]

    return {
        "user_id": user_id,
        "overall_score": overall,
        "overall_status": _score_band(overall),
        "categories": categories,
        "generated_at": _now().isoformat(),
    }


# ─────────────────────────────────────────────
# INCOME & DEBT  (code3.html)
# ─────────────────────────────────────────────
_income_debt_overrides: Dict[int, Dict] = {}

def get_income_debt(user_id: int) -> Dict:
    if user_id in _income_debt_overrides:
        return _income_debt_overrides[user_id]

    row = _get_user_row(user_id)
    if row is None:
        return {}

    yearly  = row["yearly_income_num"]
    monthly = round(yearly / 12, 2)
    pci     = row["per_capita_income_num"]
    debt    = row["total_debt_num"]

    salary      = round(monthly * 0.82, 2)
    freelance   = round(monthly * 0.12, 2)
    investments = round(monthly * 0.06, 2)

    mortgage_bal = round(debt * 0.72, 2)
    car_bal      = round(debt * 0.18, 2)
    cc_bal       = round(debt * 0.10, 2)

    income_sources = [
        {"source": "Primary Salary",    "amount": salary,      "frequency": "monthly", "type": "salary"},
        {"source": "Freelance / Side",  "amount": freelance,   "frequency": "monthly", "type": "freelance"},
        {"source": "Investments",        "amount": investments, "frequency": "monthly", "type": "investment"},
    ]

    debts = []
    if mortgage_bal > 5000:
        debts.append({
            "name": "Home Mortgage", "balance": mortgage_bal,
            "interest_rate": 3.75, "min_payment": round(mortgage_bal * 0.004, 2),
            "due_date": str(_today().replace(day=1)), "type": "mortgage",
        })
    if car_bal > 1000:
        debts.append({
            "name": "Auto Loan", "balance": car_bal,
            "interest_rate": 5.9, "min_payment": round(car_bal * 0.025, 2),
            "due_date": str(_today().replace(day=15)), "type": "loan",
        })
    if cc_bal > 100:
        debts.append({
            "name": "Credit Card Balance", "balance": cc_bal,
            "interest_rate": 19.99, "min_payment": round(cc_bal * 0.02, 2),
            "due_date": str(_today().replace(day=22)), "type": "credit_card",
        })

    est_min = sum(d["min_payment"] for d in debts)
    dti     = round(est_min / monthly, 4) if monthly else 0

    return {
        "user_id": user_id,
        "total_monthly_income": monthly,
        "total_debt": debt,
        "debt_to_income_ratio": dti,
        "income_sources": income_sources,
        "debts": debts,
    }

def update_income_debt(user_id: int, payload: Dict) -> Dict:
    current = get_income_debt(user_id)
    if payload.get("income_sources") is not None:
        current["income_sources"] = payload["income_sources"]
    if payload.get("debts") is not None:
        current["debts"] = payload["debts"]
    total_income = sum(
        s["amount"] if s["frequency"] == "monthly"
        else s["amount"] / 12 if s["frequency"] == "annual"
        else s["amount"] * 4.33
        for s in current["income_sources"]
    )
    total_debt = sum(d["balance"] for d in current["debts"])
    current["total_monthly_income"]  = round(total_income, 2)
    current["total_debt"]            = round(total_debt, 2)
    current["debt_to_income_ratio"]  = round(
        sum(d["min_payment"] for d in current["debts"]) / total_income, 4
    ) if total_income else 0
    _income_debt_overrides[user_id] = current
    return current


# ─────────────────────────────────────────────
# CARD PORTFOLIO  (code5.html)
# ─────────────────────────────────────────────
_CARD_TYPE_MAP = {
    "Credit":          "credit",
    "Debit":           "debit",
    "Debit (Prepaid)": "prepaid",
}
_BRAND_MAP = {
    "Visa":       "visa",
    "Mastercard": "mastercard",
    "Amex":       "amex",
    "Discover":   "discover",
}

def get_card_portfolio(user_id: int) -> Dict:
    row   = _get_user_row(user_id)
    cards = _get_user_cards(user_id)

    if row is None or cards.empty:
        return {"user_id": user_id, "cards": [], "total_credit_limit": 0,
                "total_balance": 0, "overall_utilization_pct": 0}

    credit_score = int(row["credit_score"])

    built = []
    for _, c in cards.iterrows():
        limit   = c["credit_limit_num"]
        util    = max(0.05, min(0.9, 1 - (credit_score - 300) / 800))
        balance = round(limit * util * random.uniform(0.6, 1.0), 2) if limit > 100 else 0.0
        avail   = round(limit - balance, 2)
        util_pct = round(balance / limit * 100, 1) if limit else 0

        raw_num = str(c["card_number"])
        last4   = raw_num[-4:]
        expires_str = str(c["expires"])

        try:
            open_yr = int(str(c["acct_open_date"]).split("/")[-1])
            age_yrs = max(0, 2024 - open_yr)
        except Exception:
            age_yrs = 1
        rewards = round(age_yrs * 1200 + limit * 0.05, 0)

        built.append({
            "id":                f"card_{int(c['id'])}",
            "name":              f"{c['card_brand']} {c['card_type']}",
            "issuer":            c["card_brand"],
            "last4":             last4,
            "card_type":         _BRAND_MAP.get(c["card_brand"], "visa"),
            "account_type":      _CARD_TYPE_MAP.get(c["card_type"], "debit"),
            "credit_limit":      limit,
            "current_balance":   balance,
            "available_credit":  avail,
            "utilization_pct":   util_pct,
            "interest_rate":     round(random.uniform(15.9, 24.9), 2),
            "expires":           expires_str,
            "has_chip":          c["has_chip"] == "YES",
            "rewards_balance":   rewards,
        })

    total_limit   = sum(c["credit_limit"]    for c in built)
    total_balance = sum(c["current_balance"] for c in built)
    overall_util  = round(total_balance / total_limit * 100, 2) if total_limit else 0

    return {
        "user_id":               user_id,
        "cards":                 built,
        "total_credit_limit":    total_limit,
        "total_balance":         total_balance,
        "overall_utilization_pct": overall_util,
    }


# ─────────────────────────────────────────────
# TRANSACTIONS  (code4.html)
# ─────────────────────────────────────────────
_CATEGORIES = ["food", "transport", "utilities", "entertainment", "health", "shopping", "other"]
_MERCHANTS  = ["Amazon", "Walmart", "Starbucks", "Uber", "Netflix",
               "Spotify", "Whole Foods", "CVS", "Shell", "Target"]
_TRANSACTIONS: Dict[int, List[Dict]] = {}

def _generate_transactions(user_id: int, n: int = 60) -> List[Dict]:
    row = _get_user_row(user_id)
    cards = _get_user_cards(user_id)

    monthly_income = row["yearly_income_num"] / 12 if row is not None else 4000
    avg_spend      = monthly_income * 0.65 / 30

    card_last4s = [str(c["card_number"])[-4:] for _, c in cards.iterrows()] or ["0000"]

    txns = []
    for i in range(n):
        days_ago  = random.randint(0, 90)
        is_income = random.random() < 0.08
        if is_income:
            amount = round(monthly_income * random.uniform(0.9, 1.1), 2)
        else:
            amount = round(-avg_spend * random.uniform(0.3, 4.5), 2)

        txns.append({
            "id":          f"txn_{user_id}_{1000 + i}",
            "date":        str(_today() - timedelta(days=days_ago)),
            "description": random.choice(_MERCHANTS) + " purchase",
            "amount":      amount,
            "category":    "income" if amount > 0 else random.choice(_CATEGORIES),
            "merchant":    random.choice(_MERCHANTS),
            "card_last4":  random.choice(card_last4s),
            "status":      random.choice(["cleared", "cleared", "cleared", "pending"]),
        })
    return sorted(txns, key=lambda x: x["date"], reverse=True)

def get_transactions(user_id: int, page=1, page_size=20,
                     search="", category="", start_date="", end_date="") -> Dict:
    if user_id not in _TRANSACTIONS:
        _TRANSACTIONS[user_id] = _generate_transactions(user_id)
    txns = list(_TRANSACTIONS[user_id])

    if search:
        txns = [t for t in txns if search.lower() in t["description"].lower()]
    if category:
        txns = [t for t in txns if t["category"] == category]
    if start_date:
        txns = [t for t in txns if t["date"] >= start_date]
    if end_date:
        txns = [t for t in txns if t["date"] <= end_date]

    total = len(txns)
    start = (page - 1) * page_size
    return {"transactions": txns[start:start + page_size],
            "total": total, "page": page, "page_size": page_size}


# ─────────────────────────────────────────────
# ML PREDICTIONS  (code2.html)
# ─────────────────────────────────────────────
def get_ml_predictions(user_id: int, timeframe: str = "3m") -> Dict:
    row = _get_user_row(user_id)
    if row is None:
        return {}

    factor        = {"1m": 1, "3m": 3, "6m": 6, "1y": 12}.get(timeframe, 3)
    credit_score  = int(row["credit_score"])
    monthly_income = row["yearly_income_num"] / 12
    total_debt    = row["total_debt_num"]

    cs_delta  = min(820 - credit_score, factor * 3) if credit_score < 750 else factor
    cf_growth = monthly_income * 0.02 * factor

    base_food          = monthly_income * 0.12
    base_transport     = monthly_income * 0.07
    base_entertainment = monthly_income * 0.05
    base_utils         = monthly_income * 0.03
    base_shopping      = monthly_income * 0.08

    dti_ratio    = total_debt / row["yearly_income_num"] if row["yearly_income_num"] else 1
    default_risk = max(0.01, min(0.45, dti_ratio * 0.18 - factor * 0.003))
    savings_opp  = round(monthly_income * 0.04 * factor, 2)

    return {
        "user_id":               user_id,
        "timeframe":             timeframe,
        "credit_score_forecast": credit_score + cs_delta,
        "cash_flow_forecast":    round(monthly_income * 0.22 + cf_growth, 2),
        "spending_predictions": [
            {"category": "Food & Dining",  "predicted_amount": round(base_food    * (1 + 0.02*factor), 2), "confidence": 0.91, "trend": "stable"},
            {"category": "Transport",       "predicted_amount": round(base_transport*(1 - 0.01*factor), 2), "confidence": 0.87, "trend": "decreasing"},
            {"category": "Entertainment",   "predicted_amount": round(base_entertainment*(1+0.05*factor),2),"confidence": 0.79, "trend": "increasing"},
            {"category": "Utilities",       "predicted_amount": round(base_utils,  2),                      "confidence": 0.95, "trend": "stable"},
            {"category": "Shopping",        "predicted_amount": round(base_shopping*(1+0.03*factor),  2),   "confidence": 0.83, "trend": "increasing"},
        ],
        "risk_of_default":  round(default_risk, 4),
        "savings_opportunity": savings_opp,
        "model_accuracy":   0.923,
        "generated_at":     _now().isoformat(),
    }


# ─────────────────────────────────────────────
# XAI INSIGHTS  (code7.html)
# ─────────────────────────────────────────────
def get_xai_insights(user_id: int) -> Dict:
    row   = _get_user_row(user_id)
    cards = _get_user_cards(user_id)

    if row is None:
        return {}

    credit_score = int(row["credit_score"])
    total_debt   = row["total_debt_num"]
    income       = row["yearly_income_num"]
    num_cards    = int(row["num_credit_cards"])
    dti_ratio    = total_debt / income if income else 1

    ph_importance = round(0.25 + (credit_score - 480) / 370 * 0.15, 2)
    ph_direction  = "positive" if credit_score >= 700 else "negative"

    total_limit   = cards["credit_limit_num"].sum()
    est_balance   = total_limit * 0.28
    util          = est_balance / total_limit if total_limit else 0.5
    util_importance = round(0.18 + util * 0.12, 2)
    util_direction  = "negative" if util > 0.3 else "positive"

    dti_importance = round(min(0.20, dti_ratio * 0.15), 2)
    dti_direction  = "negative" if dti_ratio > 0.4 else "positive"

    ages = []
    for _, c in cards.iterrows():
        try:
            yr = int(str(c["acct_open_date"]).split("/")[-1])
            ages.append(2024 - yr)
        except Exception:
            pass
    avg_age = sum(ages) / len(ages) if ages else 5
    age_importance = round(min(0.18, avg_age * 0.012), 2)

    remaining = round(max(0.05, 1.0 - ph_importance - util_importance - dti_importance - age_importance), 2)

    risk = max(0.02, min(0.45, dti_ratio * 0.3 + util * 0.2 - (credit_score - 300) / 3000))

    if credit_score >= 750:
        nl_exp = (f"Your credit risk score of {risk*100:.0f}% is low, primarily driven by a strong "
                  f"credit score of {credit_score} and {avg_age:.0f}-year average account age. "
                  f"Maintaining current payment habits will keep your score in the excellent range.")
    elif credit_score >= 680:
        nl_exp = (f"Your risk score of {risk*100:.0f}% reflects a good credit history "
                  f"(score: {credit_score}), though a debt load of {_fmt(total_debt)} relative to income "
                  f"is the main drag. Reducing high-interest balances will lower your risk below 10%.")
    else:
        nl_exp = (f"Your risk score of {risk*100:.0f}% is elevated, driven by a credit score of "
                  f"{credit_score} and a debt-to-income ratio of {dti_ratio:.1%}. "
                  f"Focus on on-time payments and reducing revolving balances.")

    return {
        "user_id":          user_id,
        "model_name":       "FinSight-XGBoost-v3",
        "prediction_label": "Credit Risk Score",
        "prediction_value": round(risk, 3),
        "confidence":       0.94,
        "top_features": [
            {"feature": "Payment History",    "importance": ph_importance,   "direction": ph_direction,
             "explanation": f"Credit score {credit_score} reflects long-term payment discipline."},
            {"feature": "Credit Utilisation", "importance": util_importance, "direction": util_direction,
             "explanation": f"Est. utilisation {util*100:.0f}% across {num_cards} cards."},
            {"feature": "Debt-to-Income",     "importance": dti_importance,  "direction": dti_direction,
             "explanation": f"Total debt {_fmt(total_debt)} vs income {_fmt(income)}."},
            {"feature": "Account Age",        "importance": age_importance,  "direction": "positive",
             "explanation": f"Average account age ~{avg_age:.0f} years indicates stable history."},
            {"feature": "Credit Mix",         "importance": remaining,       "direction": "positive",
             "explanation": f"{num_cards} cards across {cards['card_brand'].nunique()} brands."},
        ],
        "natural_language_explanation": nl_exp,
        "generated_at": _now().isoformat(),
    }


# ─────────────────────────────────────────────
# RISK CENTER  (code6.html)
# ─────────────────────────────────────────────
def get_risk_report(user_id: int) -> Dict:
    row   = _get_user_row(user_id)
    cards = _get_user_cards(user_id)

    if row is None:
        return {}

    credit_score = int(row["credit_score"])
    income       = row["yearly_income_num"]
    total_debt   = row["total_debt_num"]
    num_cards    = int(row["num_credit_cards"])
    dti_ratio    = total_debt / income if income else 1

    market_score = max(10, min(90, 100 - (credit_score - 480) / 3.7))
    market_sev   = "high" if market_score > 65 else "medium" if market_score > 40 else "low"

    pci       = row["per_capita_income_num"]
    monthly   = income / 12
    ef_months = max(0, pci / (monthly * 0.4))
    liq_score = max(10, min(90, 100 - ef_months * 12))
    liq_sev   = "high" if liq_score > 65 else "medium" if liq_score > 40 else "low"

    total_limit = cards["credit_limit_num"].sum()
    cc_score    = min(80, num_cards * 8 + 10)
    cc_sev      = "low" if cc_score < 30 else "medium" if cc_score < 55 else "high"

    inc_score = max(20, min(80, dti_ratio * 90))
    inc_sev   = "high" if inc_score > 65 else "medium" if inc_score > 40 else "low"

    overall = round((market_score + liq_score + cc_score + inc_score) / 4, 1)
    if overall < 30:   risk_level = "low"
    elif overall < 55: risk_level = "medium"
    elif overall < 75: risk_level = "high"
    else:              risk_level = "critical"

    return {
        "user_id":            user_id,
        "overall_risk_score": overall,
        "risk_level":         risk_level,
        "factors": [
            {
                "name":        "Market Volatility Exposure",
                "severity":    market_sev,
                "score":       round(market_score, 1),
                "description": f"Credit profile (score {credit_score}) influences market sensitivity.",
                "mitigation":  "Diversify into low-volatility bonds or dividend stocks.",
            },
            {
                "name":        "Liquidity Risk",
                "severity":    liq_sev,
                "score":       round(liq_score, 1),
                "description": f"~{ef_months:.1f} months emergency fund estimated from income data.",
                "mitigation":  "Build liquid reserve to cover 6 months of expenses.",
            },
            {
                "name":        "Credit Concentration",
                "severity":    cc_sev,
                "score":       round(cc_score, 1),
                "description": f"{num_cards} active cards across {cards['card_brand'].nunique()} brands.",
                "mitigation":  "Keep individual card utilisation below 10%.",
            },
            {
                "name":        "Income Concentration",
                "severity":    inc_sev,
                "score":       round(inc_score, 1),
                "description": f"DTI ratio {dti_ratio:.1%} — debt {_fmt(total_debt)} vs income {_fmt(income)}.",
                "mitigation":  "Grow alternative income streams to reduce dependence on single source.",
            },
        ],
        "generated_at": _now().isoformat(),
    }


# ─────────────────────────────────────────────
# MARKET TRENDS  (code8.html)
# ─────────────────────────────────────────────
def get_market_trends() -> Dict:
    def _ticker(sym, name, price, chg, sector):
        return {
            "symbol": sym, "name": name, "price": price,
            "change": round(chg, 2),
            "change_pct": round(chg / price * 100, 3),
            "volume": random.randint(1_000_000, 80_000_000),
            "sector": sector,
        }
    return {
        "indices": [
            _ticker("SPX",  "S&P 500",    5_421.30,   18.40, "index"),
            _ticker("NDX",  "NASDAQ 100", 19_034.80,  55.20, "index"),
            _ticker("DJI",  "Dow Jones",  38_621.90, -42.10, "index"),
            _ticker("VIX",  "Volatility",     14.32,   0.84, "index"),
        ],
        "top_gainers": [
            _ticker("NVDA", "NVIDIA Corp",    875.40, 42.30, "Technology"),
            _ticker("TSLA", "Tesla Inc",       185.60,  8.90, "Automotive"),
            _ticker("META", "Meta Platforms",  498.20, 21.10, "Technology"),
        ],
        "top_losers": [
            _ticker("INTC", "Intel Corp",   31.50, -2.40, "Technology"),
            _ticker("PFE",  "Pfizer Inc",   27.80, -1.10, "Healthcare"),
            _ticker("BA",   "Boeing Co",   175.20, -6.80, "Aerospace"),
        ],
        "trending": [
            _ticker("AAPL",  "Apple Inc",  189.30,  3.50, "Technology"),
            _ticker("AMZN",  "Amazon.com", 182.70,  2.10, "E-Commerce"),
            _ticker("MSFT",  "Microsoft",  415.80,  5.60, "Technology"),
            _ticker("GOOGL", "Alphabet",   171.20,  1.80, "Technology"),
        ],
        "market_sentiment": "bullish",
        "last_updated": _now().isoformat(),
    }


# ─────────────────────────────────────────────
# PORTFOLIO ANALYTICS  (extra endpoint)
# ─────────────────────────────────────────────
def get_portfolio_analytics() -> Dict:
    cs_mean   = round(_users_df["credit_score"].mean(), 1)
    inc_mean  = round(_users_df["yearly_income_num"].mean(), 2)
    debt_mean = round(_users_df["total_debt_num"].mean(), 2)

    brand_dist = _cards_df["card_brand"].value_counts().to_dict()
    type_dist  = _cards_df["card_type"].value_counts().to_dict()
    chip_dist  = _cards_df["has_chip"].value_counts().to_dict()

    return {
        "total_users":             len(_users_df),
        "total_cards":             len(_cards_df),
        "avg_credit_score":        cs_mean,
        "avg_yearly_income":       inc_mean,
        "avg_total_debt":          debt_mean,
        "avg_cards_per_user":      round(len(_cards_df) / len(_users_df), 2),
        "card_brand_distribution": brand_dist,
        "card_type_distribution":  type_dist,
        "chip_distribution":       chip_dist,
        "gender_split":            _users_df["gender"].value_counts().to_dict(),
        "age_range": {
            "min": int(_users_df["current_age"].min()),
            "max": int(_users_df["current_age"].max()),
            "avg": round(_users_df["current_age"].mean(), 1),
        },
        "generated_at": _now().isoformat(),
    }
