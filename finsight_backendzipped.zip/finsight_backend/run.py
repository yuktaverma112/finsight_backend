"""
FinSight Pro - Start Server
Run: python run.py
Then open: http://localhost:8000/ui/code1.html
"""
import uvicorn

if __name__ == "__main__":
    print("\n" + "="*55)
    print("  FinSight Pro Backend")
    print("="*55)
    print("  Dashboard:        http://localhost:8000/ui/code1.html")
    print("  Financial Health: http://localhost:8000/ui/code.html")
    print("  ML Predictions:   http://localhost:8000/ui/code2.html")
    print("  Income & Debt:    http://localhost:8000/ui/code3.html")
    print("  Transactions:     http://localhost:8000/ui/code4.html")
    print("  Card Portfolio:   http://localhost:8000/ui/code5.html")
    print("  Risk Center:      http://localhost:8000/ui/code6.html")
    print("  XAI Insights:     http://localhost:8000/ui/code7.html")
    print("  Market Trends:    http://localhost:8000/ui/code8.html")
    print("  API Docs:         http://localhost:8000/docs")
    print("="*55 + "\n")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
