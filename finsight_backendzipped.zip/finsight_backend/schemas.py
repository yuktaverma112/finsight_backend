"""
Shared Pydantic schemas for FinSight Pro.
"""

from __future__ import annotations
from datetime import date, datetime
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
class LoginRequest(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: str
    name: str


# ---------------------------------------------------------------------------
# Dashboard  (code1.html – Intelligence Terminal / Overview)
# ---------------------------------------------------------------------------
class KPICard(BaseModel):
    label: str
    value: str
    change: float          # percentage change
    trend: str             # "up" | "down" | "neutral"

class DashboardSummary(BaseModel):
    user_id: str
    net_worth: float
    credit_score: int
    monthly_cash_flow: float
    debt_to_income_ratio: float
    kpi_cards: List[KPICard]
    last_updated: datetime


# ---------------------------------------------------------------------------
# Financial Health  (code.html)
# ---------------------------------------------------------------------------
class HealthCategory(BaseModel):
    name: str
    score: int             # 0-100
    status: str            # "excellent" | "good" | "fair" | "poor"
    recommendation: str

class FinancialHealthReport(BaseModel):
    user_id: str
    overall_score: int
    overall_status: str
    categories: List[HealthCategory]
    generated_at: datetime


# ---------------------------------------------------------------------------
# Income & Debt  (code3.html)
# ---------------------------------------------------------------------------
class IncomeSource(BaseModel):
    source: str
    amount: float
    frequency: str         # "monthly" | "weekly" | "annual"
    type: str              # "salary" | "freelance" | "investment" | "other"

class DebtItem(BaseModel):
    name: str
    balance: float
    interest_rate: float
    min_payment: float
    due_date: Optional[date]
    type: str              # "credit_card" | "loan" | "mortgage" | "other"

class IncomeDebtProfile(BaseModel):
    user_id: str
    total_monthly_income: float
    total_debt: float
    debt_to_income_ratio: float
    income_sources: List[IncomeSource]
    debts: List[DebtItem]

class IncomeDebtUpdate(BaseModel):
    income_sources: Optional[List[IncomeSource]] = None
    debts: Optional[List[DebtItem]] = None


# ---------------------------------------------------------------------------
# Transactions  (code4.html)
# ---------------------------------------------------------------------------
class TransactionCategory(str, Enum):
    food = "food"
    transport = "transport"
    utilities = "utilities"
    entertainment = "entertainment"
    health = "health"
    shopping = "shopping"
    income = "income"
    transfer = "transfer"
    other = "other"

class Transaction(BaseModel):
    id: str
    date: date
    description: str
    amount: float          # negative = debit, positive = credit
    category: TransactionCategory
    merchant: Optional[str] = None
    card_last4: Optional[str] = None
    status: str = "cleared"  # "cleared" | "pending" | "failed"

class TransactionList(BaseModel):
    transactions: List[Transaction]
    total: int
    page: int
    page_size: int

class TransactionFilter(BaseModel):
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    category: Optional[TransactionCategory] = None
    min_amount: Optional[float] = None
    max_amount: Optional[float] = None
    search: Optional[str] = None


# ---------------------------------------------------------------------------
# Card Portfolio  (code5.html)
# ---------------------------------------------------------------------------
class CreditCard(BaseModel):
    id: str
    name: str
    issuer: str
    last4: str
    credit_limit: float
    current_balance: float
    available_credit: float
    utilization_pct: float
    interest_rate: float
    due_date: Optional[date] = None
    rewards_balance: float = 0.0
    card_type: str         # "visa" | "mastercard" | "amex" | "discover"

class CardPortfolio(BaseModel):
    user_id: str
    cards: List[CreditCard]
    total_credit_limit: float
    total_balance: float
    overall_utilization_pct: float


# ---------------------------------------------------------------------------
# ML Predictions  (code2.html)
# ---------------------------------------------------------------------------
class PredictionTimeframe(str, Enum):
    one_month = "1m"
    three_months = "3m"
    six_months = "6m"
    one_year = "1y"

class SpendingPrediction(BaseModel):
    category: str
    predicted_amount: float
    confidence: float      # 0-1
    trend: str             # "increasing" | "decreasing" | "stable"

class MLPredictionReport(BaseModel):
    user_id: str
    timeframe: str
    credit_score_forecast: int
    cash_flow_forecast: float
    spending_predictions: List[SpendingPrediction]
    risk_of_default: float      # 0-1
    savings_opportunity: float
    model_accuracy: float
    generated_at: datetime


# ---------------------------------------------------------------------------
# XAI Insights  (code7.html)
# ---------------------------------------------------------------------------
class FeatureImportance(BaseModel):
    feature: str
    importance: float      # 0-1
    direction: str         # "positive" | "negative"
    explanation: str

class XAIInsightReport(BaseModel):
    user_id: str
    model_name: str
    prediction_label: str
    prediction_value: float
    confidence: float
    top_features: List[FeatureImportance]
    natural_language_explanation: str
    generated_at: datetime


# ---------------------------------------------------------------------------
# Risk Center  (code6.html)
# ---------------------------------------------------------------------------
class RiskFactor(BaseModel):
    name: str
    severity: str          # "low" | "medium" | "high" | "critical"
    score: float           # 0-100
    description: str
    mitigation: str

class RiskReport(BaseModel):
    user_id: str
    overall_risk_score: float
    risk_level: str        # "low" | "medium" | "high" | "critical"
    factors: List[RiskFactor]
    generated_at: datetime


# ---------------------------------------------------------------------------
# Market Trends  (code8.html)
# ---------------------------------------------------------------------------
class MarketTicker(BaseModel):
    symbol: str
    name: str
    price: float
    change: float
    change_pct: float
    volume: int
    sector: str

class MarketSummary(BaseModel):
    indices: List[MarketTicker]
    top_gainers: List[MarketTicker]
    top_losers: List[MarketTicker]
    trending: List[MarketTicker]
    market_sentiment: str   # "bullish" | "bearish" | "neutral"
    last_updated: datetime
