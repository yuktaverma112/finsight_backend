# FinSight Pro — Backend Setup Guide

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Start the server
```bash
python run.py
```

### 3. Open your browser
Click any link to open the UI:

| Interface | URL |
|-----------|-----|
| 📊 Dashboard (Overview) | http://localhost:8000/ui/code1.html |
| 💚 Financial Health | http://localhost:8000/ui/code.html |
| 🤖 ML Predictions | http://localhost:8000/ui/code2.html |
| 💰 Income & Debt | http://localhost:8000/ui/code3.html |
| 🧾 Transactions | http://localhost:8000/ui/code4.html |
| 💳 Card Portfolio | http://localhost:8000/ui/code5.html |
| 🔐 Risk Center | http://localhost:8000/ui/code6.html |
| 🧠 XAI Insights | http://localhost:8000/ui/code7.html |
| 📈 Market Trends | http://localhost:8000/ui/code8.html |
| 📖 API Docs (Swagger) | http://localhost:8000/docs |

---

## What was connected

All 9 HTML interfaces now:
- **Navigate to each other** via the sidebar icon/link clicks
- **Fetch live data** from the Python FastAPI backend on load
- **Show a toast notification** confirming data loaded (or a warning if the API is offline)

---

## API Endpoints

| Prefix | Router | Powers |
|--------|--------|--------|
| /api/auth | auth.py | Login / logout |
| /api/dashboard | dashboard.py | code1.html |
| /api/financial-health | financial_health.py | code.html |
| /api/ml | ml_predictions.py | code2.html |
| /api/income-debt | income_debt.py | code3.html |
| /api/transactions | transactions.py | code4.html |
| /api/cards | card_portfolio.py | code5.html |
| /api/risk | risk_center.py | code6.html |
| /api/xai | xai_insights.py | code7.html |
| /api/markets | market_trends.py | code8.html |

---

## Project Structure

```
finsight_backend/
├── main.py              # FastAPI app, CORS, router registration
├── database.py          # In-memory mock data store
├── schemas.py           # Pydantic models
├── run.py               # Launch script (python run.py)
├── requirements.txt
├── html/
│   ├── code.html        # Financial Health Analyzer
│   ├── code1.html       # Dashboard / Intelligence Terminal
│   ├── code2.html       # ML Predictions
│   ├── code3.html       # Income & Debt
│   ├── code4.html       # Transactions
│   ├── code5.html       # Card Portfolio
│   ├── code6.html       # Risk Center
│   ├── code7.html       # XAI Insights
│   └── code8.html       # Market Trends
└── routers/
    ├── auth.py
    ├── dashboard.py
    ├── financial_health.py
    ├── income_debt.py
    ├── transactions.py
    ├── card_portfolio.py
    ├── ml_predictions.py
    ├── xai_insights.py
    ├── risk_center.py
    └── market_trends.py
```

## Demo Login
- **Email:** alex@finsightpro.io
- **Password:** any (demo mode, no password check)

## Connecting to a real database
Replace the functions in `database.py` with SQLAlchemy / MongoDB calls.
The router files and schemas don't need to change.
