from routers import (
    auth, dashboard, financial_health, income_debt,
    transactions, card_portfolio, ml_predictions,
    xai_insights, risk_center, market_trends, analytics,
)
