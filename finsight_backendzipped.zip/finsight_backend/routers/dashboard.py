from fastapi import APIRouter, Query
from database import get_dashboard

router = APIRouter()

@router.get("/summary")
def dashboard_summary(user_id: int = Query(default=825)):
    """Powers code1.html. Default user_id=825 (first user in dataset)."""
    return get_dashboard(user_id)
