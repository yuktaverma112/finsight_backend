from fastapi import APIRouter, HTTPException
from schemas import LoginRequest, TokenResponse
from database import TOKENS, get_user_by_email, get_user_by_id, list_all_user_ids
import secrets

router = APIRouter()


@router.post("/login", response_model=TokenResponse)
def login(req: LoginRequest):
    # Accept  user{id}@finsightpro.io  OR  any email → default to user 825
    user = get_user_by_email(req.email)
    if not user:
        # fallback: use first real user from dataset
        first_id = list_all_user_ids()[0]
        user = get_user_by_id(first_id)
    token = secrets.token_hex(32)
    TOKENS[token] = user["id"]
    return TokenResponse(access_token=token, user_id=str(user["id"]), name=user["name"])


@router.post("/logout")
def logout(token: str):
    TOKENS.pop(token, None)
    return {"message": "Logged out"}


@router.get("/me")
def me(token: str):
    user_id = TOKENS.get(token)
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    user = get_user_by_id(user_id)
    return user


@router.get("/users")
def list_users(limit: int = 20):
    """List available user IDs from the dataset (for demo switching)."""
    ids = list_all_user_ids()[:limit]
    return {"user_ids": ids, "total": len(list_all_user_ids())}
