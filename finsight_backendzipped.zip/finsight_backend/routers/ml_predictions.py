from fastapi import APIRouter, Query, HTTPException
from database import get_ml_predictions

router = APIRouter()
VALID_TIMEFRAMES = {"1m", "3m", "6m", "1y"}

@router.get("/predictions")
def ml_predictions(
    user_id: int = Query(default=825),
    timeframe: str = Query(default="3m", description="1m | 3m | 6m | 1y"),
):
    if timeframe not in VALID_TIMEFRAMES:
        raise HTTPException(status_code=400, detail=f"timeframe must be one of {VALID_TIMEFRAMES}")
    return get_ml_predictions(user_id, timeframe)
