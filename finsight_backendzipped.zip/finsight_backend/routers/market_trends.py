from fastapi import APIRouter, Query
from database import get_market_trends

router = APIRouter()


@router.get("/summary")
def market_summary():
    """
    Powers code8.html – Market Trends.
    Returns major indices, top gainers/losers, trending tickers
    and overall market sentiment.
    """
    return get_market_trends()


@router.get("/ticker/{symbol}")
def ticker(symbol: str):
    """Single ticker lookup."""
    data   = get_market_trends()
    all_tickers = (
        data["indices"]
        + data["top_gainers"]
        + data["top_losers"]
        + data["trending"]
    )
    match = next((t for t in all_tickers if t["symbol"].upper() == symbol.upper()), None)
    if not match:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Ticker {symbol} not found")
    return match
