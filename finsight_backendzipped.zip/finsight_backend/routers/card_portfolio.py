from fastapi import APIRouter, Query, HTTPException
from database import get_card_portfolio

router = APIRouter()

@router.get("/portfolio")
def card_portfolio(user_id: int = Query(default=825)):
    return get_card_portfolio(user_id)

@router.get("/{card_id}")
def get_card(card_id: str, user_id: int = Query(default=825)):
    portfolio = get_card_portfolio(user_id)
    card = next((c for c in portfolio["cards"] if c["id"] == card_id), None)
    if not card:
        raise HTTPException(status_code=404, detail="Card not found")
    return card
