from fastapi import APIRouter, Query
from database import get_financial_health

router = APIRouter()

@router.get("/report")
def financial_health_report(user_id: int = Query(default=825)):
    """Powers code.html – Financial Health Analyzer."""
    return get_financial_health(user_id)
