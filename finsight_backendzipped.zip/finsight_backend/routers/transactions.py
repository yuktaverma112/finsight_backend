from fastapi import APIRouter, Query, HTTPException
from database import get_transactions, _TRANSACTIONS
from schemas import Transaction, TransactionCategory
import uuid

router = APIRouter()

@router.get("/")
def list_transactions(
    user_id:    int = Query(default=825),
    page:       int = Query(default=1, ge=1),
    page_size:  int = Query(default=20, ge=1, le=100),
    search:     str = Query(default=""),
    category:   str = Query(default=""),
    start_date: str = Query(default=""),
    end_date:   str = Query(default=""),
):
    return get_transactions(user_id, page, page_size, search, category, start_date, end_date)

@router.get("/{txn_id}")
def get_transaction(txn_id: str, user_id: int = Query(default=825)):
    txns = _TRANSACTIONS.get(user_id, [])
    txn  = next((t for t in txns if t["id"] == txn_id), None)
    if not txn:
        raise HTTPException(status_code=404, detail="Transaction not found")
    return txn

@router.post("/", status_code=201)
def add_transaction(txn: Transaction, user_id: int = Query(default=825)):
    if user_id not in _TRANSACTIONS:
        _TRANSACTIONS[user_id] = []
    record = txn.model_dump()
    record["id"] = f"txn_{uuid.uuid4().hex[:8]}"
    _TRANSACTIONS[user_id].insert(0, record)
    return record

@router.get("/summary/by-category")
def spending_by_category(
    user_id:    int = Query(default=825),
    start_date: str = Query(default=""),
    end_date:   str = Query(default=""),
):
    result = get_transactions(user_id, 1, 1000, "", "", start_date, end_date)
    totals: dict = {}
    for t in result["transactions"]:
        if t["amount"] < 0:
            cat = t["category"]
            totals[cat] = round(totals.get(cat, 0) + abs(t["amount"]), 2)
    return {"categories": [{"category": k, "total": v} for k, v in sorted(totals.items(), key=lambda x: -x[1])]}
