from fastapi import APIRouter, Query
from database import get_xai_insights

router = APIRouter()

@router.get("/insights")
def xai_insights(user_id: int = Query(default=825)):
    return get_xai_insights(user_id)
