from fastapi import APIRouter, Query
from database import get_risk_report

router = APIRouter()

@router.get("/report")
def risk_report(user_id: int = Query(default=825)):
    return get_risk_report(user_id)
