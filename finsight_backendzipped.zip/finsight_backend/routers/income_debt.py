from fastapi import APIRouter, Query
from schemas import IncomeDebtUpdate
from database import get_income_debt, update_income_debt

router = APIRouter()

@router.get("/profile")
def income_debt_profile(user_id: int = Query(default=825)):
    return get_income_debt(user_id)

@router.put("/profile")
def update_profile(payload: IncomeDebtUpdate, user_id: int = Query(default=825)):
    data = payload.model_dump(exclude_none=True)
    return update_income_debt(user_id, data)
