from fastapi import APIRouter
from database import get_portfolio_analytics

router = APIRouter()

@router.get("/portfolio")
def portfolio_analytics():
    """
    Aggregate stats across all 2000 users and 6146 cards in the dataset.
    Card brand split, type split, avg credit score, income, debt, age range.
    """
    return get_portfolio_analytics()
