"""
FinSight Pro - FastAPI Backend
Connected to real datasets: users_data.csv (2000 users) + cards_data.csv (6146 cards)

Interfaces:
  code.html  → Financial Health Analyzer
  code1.html → Intelligence Terminal (Dashboard)
  code2.html → ML Predictions
  code3.html → Income & Debt
  code4.html → Transactions
  code5.html → Card Portfolio
  code6.html → Risk Center
  code7.html → XAI Insights
  code8.html → Market Trends
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from routers import (
    dashboard, financial_health, income_debt, transactions,
    card_portfolio, ml_predictions, xai_insights, risk_center,
    market_trends, auth,
)
from routers import analytics

app = FastAPI(
    title="FinSight Pro API",
    description="Backend powered by real user & card datasets (2000 users, 6146 cards)",
    version="2.2.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

HTML_DIR = os.path.join(os.path.dirname(__file__), "html")
if os.path.isdir(HTML_DIR):
    app.mount("/ui", StaticFiles(directory=HTML_DIR, html=True), name="ui")

app.include_router(auth.router,             prefix="/api/auth",             tags=["Auth"])
app.include_router(dashboard.router,        prefix="/api/dashboard",        tags=["Dashboard"])
app.include_router(financial_health.router, prefix="/api/financial-health", tags=["Financial Health"])
app.include_router(income_debt.router,      prefix="/api/income-debt",      tags=["Income & Debt"])
app.include_router(transactions.router,     prefix="/api/transactions",     tags=["Transactions"])
app.include_router(card_portfolio.router,   prefix="/api/cards",            tags=["Card Portfolio"])
app.include_router(ml_predictions.router,   prefix="/api/ml",               tags=["ML Predictions"])
app.include_router(xai_insights.router,     prefix="/api/xai",              tags=["XAI Insights"])
app.include_router(risk_center.router,      prefix="/api/risk",             tags=["Risk Center"])
app.include_router(market_trends.router,    prefix="/api/markets",          tags=["Market Trends"])
app.include_router(analytics.router,        prefix="/api/analytics",        tags=["Analytics"])


@app.get("/", tags=["Root"])
def root():
    return {
        "app": "FinSight Pro API",
        "version": "2.2.0",
        "dataset": {"users": 2000, "cards": 6146},
        "docs": "/docs",
        "interfaces": {
            "dashboard":        "/ui/code1.html",
            "financial_health": "/ui/code.html",
            "ml_predictions":   "/ui/code2.html",
            "income_debt":      "/ui/code3.html",
            "transactions":     "/ui/code4.html",
            "card_portfolio":   "/ui/code5.html",
            "risk_center":      "/ui/code6.html",
            "xai_insights":     "/ui/code7.html",
            "market_trends":    "/ui/code8.html",
        },
        "tip": "Add ?user_id=<id> to any endpoint. List users at /api/auth/users"
    }
